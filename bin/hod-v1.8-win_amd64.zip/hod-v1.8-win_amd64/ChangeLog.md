# Contents

- [v1.8](#v18)
- [v1.7](#v17)
- [v1.6](#v16)

1.8
===
* Add flag `-g` to create byte array for go
_(Sep-15-2025)_

1.7
===
* Added flag `-i` to create C header file. Added man page and install target.  
_(Apr-04-2012)_

* Can create debian binary package. Created man page. 
_(May-13-2012)_

1.6
===
* In windows, under cygin, stdout was not binary, so reverse hexdump was getting corrupted. Thanks to Sebastien Trottier.  
_(Jun-25-2006)_
